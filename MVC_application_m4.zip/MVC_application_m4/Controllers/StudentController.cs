﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_application_m4.Models;

namespace MVC_application_m4.Controllers
{
    public class StudentController : Controller
    {

        TrainingPuneEntities context = new TrainingPuneEntities();
        // GET: Student
        public ActionResult Index()
        {

          return  View(context.Student_master);
        }
        [HttpGet]
        public ActionResult Create()
        {
            // return View("Index", context.Student_master);
            // return RedirectToAction("Index");
            return View();
        }
        [HttpPost]
        public ActionResult Create(Student_master std)
        {
            context.Student_master.Add(std);
            context.SaveChanges();
            return  RedirectToAction("Index");
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            Student_master std = (from p in context.Student_master
                      where p.Stud_Code == id
                      select p).Single();

            return View(std);
        }
        [HttpPost]
        public ActionResult Edit(Student_master std)
        {
            var std1= (from p in context.Student_master
                       where p.Stud_Code == std.Stud_Code
                       select p).Single();
            std1.Stud_Name = std.Stud_Name;
            std1.Stud_Dob = std.Stud_Dob;
            std1.Dept_Code = std.Dept_Code;
            std1.Address = std.Address;
            context.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Delete(int id)
        {
            Student_master std = (from p in context.Student_master
                                  where p.Stud_Code == id
                                  select p).Single();
            context.Student_master.Remove(std);
            context.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult Search(Student_master std)
        {
            Student_master std1 = null;
            try
            {
                
                std1 = (from p in context.Student_master
                                       where p.Stud_Code == std.Stud_Code 
                                       select p).First();

                ViewBag.message = null;
                return View(std1);
                
            }
            catch(Exception ex)
            {
                ViewBag.message = string.Format(std.Stud_Code+" details are not found"+"<br/>"+ex.Message);
                return View(std1);
            }
           
        }

       
         //employee start with a
         //employee dept range 
         //employee city specific
         // public ActinResult Search
        // public ActionResult Searchspecific()
        //{
        //    Student_master std1=(fron)
        //}
    }
}